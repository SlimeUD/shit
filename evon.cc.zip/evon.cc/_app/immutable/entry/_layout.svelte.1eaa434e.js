import{S as ae,i as ne,s as re,C as oe,H as le,a as A,k as d,q as S,y as ie,D as ce,c as D,E as de,l as u,m as w,h as n,r as C,z as ue,n as t,F as j,p as T,b as L,G as r,A as fe,I as he,J as pe,K as me,g as ee,d as te,B as _e,L as ve}from"../chunks/index.1bed02e8.js";import{s as ye}from"../chunks/singletons.2b1a5fda.js";import{B as ge}from"../chunks/Button.8a9b321f.js";const be=()=>{const o=ye;return{page:{subscribe:o.page.subscribe},navigating:{subscribe:o.navigating.subscribe},updated:o.updated}},we={subscribe(o){return be().page.subscribe(o)}};function Ee(o){let l;return{c(){l=S("Download")},l(f){l=C(f,"Download")},m(f,h){L(f,l,h)},d(f){f&&n(l)}}}function ke(o){let l,f="<!-- Copyright (c) 2023 Expo. All Rights Reserved. -->",h,v,m,i,F,y,J,I,H,B,s,E,_,K,N,k,q,G,$,P,U,g,W,z,b,M,R;b=new ge({props:{link:o[0].url.pathname==="/"?"dl":"dl-a",filled:!0,shimmer:!0,styles:"margin-left: auto;",$$slots:{default:[Ee]},$$scope:{ctx:o}}});const Y=o[1].default,c=oe(Y,o,o[2],null);return{c(){l=new le(!1),h=A(),v=d("meta"),m=d("meta"),i=d("script"),y=d("script"),I=d("style"),H=S(`/*!
     * @license "THE BEER-WARE LICENSE" (Revision 42):
     * <pleasego@nuke.africa> wrote this file. As long as you retain this notice you
     * can do whatever you want with this stuff. If we meet some day, and you think
     * this stuff is worth it, you can buy me a beer in return | Expo
     */
    /* no-dark-reader.css */
    /* Notifies the user to stop using dark reader */
    html[data-darkreader-scheme] body {
      display: none;
    }
    html[data-darkreader-scheme]::before {
      content: 'This site is dark themed! Dark reader breaks this site, so please disable it.';
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      padding-top: 0.5em;
      text-align: center;
      background: #1e2030;
    }`),B=A(),s=d("nav"),E=d("a"),_=d("img"),N=A(),k=d("a"),q=S("Android"),G=A(),$=d("a"),P=S("Discord"),U=A(),g=d("a"),W=S("Debunked"),z=A(),ie(b.$$.fragment),M=A(),c&&c.c(),this.h()},l(e){l=ce(e,!1),h=D(e);const a=de("svelte-dlgrwy",document.head);v=u(a,"META",{name:!0,content:!0}),m=u(a,"META",{name:!0,content:!0}),i=u(a,"SCRIPT",{"data-cfasync":!0,type:!0,src:!0});var x=w(i);x.forEach(n),y=u(a,"SCRIPT",{"data-cfasync":!0,src:!0});var se=w(y);se.forEach(n),I=u(a,"STYLE",{});var V=w(I);H=C(V,`/*!
     * @license "THE BEER-WARE LICENSE" (Revision 42):
     * <pleasego@nuke.africa> wrote this file. As long as you retain this notice you
     * can do whatever you want with this stuff. If we meet some day, and you think
     * this stuff is worth it, you can buy me a beer in return | Expo
     */
    /* no-dark-reader.css */
    /* Notifies the user to stop using dark reader */
    html[data-darkreader-scheme] body {
      display: none;
    }
    html[data-darkreader-scheme]::before {
      content: 'This site is dark themed! Dark reader breaks this site, so please disable it.';
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      padding-top: 0.5em;
      text-align: center;
      background: #1e2030;
    }`),V.forEach(n),a.forEach(n),B=D(e),s=u(e,"NAV",{style:!0,class:!0});var p=w(s);E=u(p,"A",{href:!0,class:!0});var Z=w(E);_=u(Z,"IMG",{src:!0,alt:!0,style:!0,class:!0}),Z.forEach(n),N=D(p),k=u(p,"A",{href:!0,class:!0});var O=w(k);q=C(O,"Android"),O.forEach(n),G=D(p),$=u(p,"A",{href:!0,class:!0});var Q=w($);P=C(Q,"Discord"),Q.forEach(n),U=D(p),g=u(p,"A",{href:!0,class:!0,"data-sveltekit-reload":!0});var X=w(g);W=C(X,"Debunked"),X.forEach(n),z=D(p),ue(b.$$.fragment,p),p.forEach(n),M=D(e),c&&c.l(e),this.h()},h(){l.a=h,document.title="Evon",t(v,"name","description"),t(v,"content","Clean and slick UI with a custom DLL, a Built-In Script List, a Powerful IDE, and more - that's Evon"),t(m,"name","theme-color"),t(m,"content","#8200fb"),t(i,"data-cfasync","false"),i.async=!0,t(i,"type","text/javascript"),j(i.src,F="https://guidonsfeeing.com/gAM7YRIoADluUqgZ/64730")||t(i,"src",F),t(y,"data-cfasync","false"),j(y.src,J="https://d1now6cui1se29.cloudfront.net/?cwond=984469")||t(y,"src",J),j(_.src,K="/i/evoncrop.png")||t(_,"src",K),t(_,"alt","Evon"),T(_,"height","20px"),T(_,"width","20px"),t(_,"class","svelte-sa2ywv"),t(E,"href","/"),t(E,"class","svelte-sa2ywv"),t(k,"href","/android"),t(k,"class","svelte-sa2ywv"),t($,"href","https://discord.gg/x5AT9UMMWG"),t($,"class","svelte-sa2ywv"),t(g,"href","https://evon.cc/debunked/"),t(g,"class","debunk svelte-sa2ywv"),t(g,"data-sveltekit-reload",""),T(s,"position","fixed"),T(s,"top","0"),T(s,"z-index","1000"),T(s,"backdrop-filter","blur(32px)"),t(s,"class","svelte-sa2ywv")},m(e,a){l.m(f,e,a),L(e,h,a),r(document.head,v),r(document.head,m),r(document.head,i),r(document.head,y),r(document.head,I),r(I,H),L(e,B,a),L(e,s,a),r(s,E),r(E,_),r(s,N),r(s,k),r(k,q),r(s,G),r(s,$),r($,P),r(s,U),r(s,g),r(g,W),r(s,z),fe(b,s,null),L(e,M,a),c&&c.m(e,a),R=!0},p(e,[a]){const x={};a&1&&(x.link=e[0].url.pathname==="/"?"dl":"dl-a"),a&4&&(x.$$scope={dirty:a,ctx:e}),b.$set(x),c&&c.p&&(!R||a&4)&&he(c,Y,e,e[2],R?me(Y,e[2],a,null):pe(e[2]),null)},i(e){R||(ee(b.$$.fragment,e),ee(c,e),R=!0)},o(e){te(b.$$.fragment,e),te(c,e),R=!1},d(e){e&&l.d(),e&&n(h),n(v),n(m),n(i),n(y),n(I),e&&n(B),e&&n(s),_e(b),e&&n(M),c&&c.d(e)}}}function $e(o,l,f){let h;ve(o,we,i=>f(0,h=i));let{$$slots:v={},$$scope:m}=l;return o.$$set=i=>{"$$scope"in i&&f(2,m=i.$$scope)},[h,v,m]}class Re extends ae{constructor(l){super(),ne(this,l,$e,ke,re,{})}}export{Re as default};